<!doctype html>
<html class="no-js" lang="">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>@yield('title')</title>
    <meta name="description" content="@yield('meta-description')">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="canonical" href="@yield('meta-canonical')" />
    <meta name="keywords"  content="@yield('meta-keywords')" />
    @include('frontend.inc.css') 
    @yield('css')

<body>
    <div class="wrapper-area">

     @include('frontend.inc.header') 
        
        @yield('content')
    
     @include('frontend.inc.footer') 

    </div>

    @include('frontend.inc.js')
    @yield('js')
</body>

</html>
