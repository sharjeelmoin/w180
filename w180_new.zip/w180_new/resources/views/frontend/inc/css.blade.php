<!-- Favicon -->
<link rel="shortcut icon" type="image/x-icon" href="{{asset('/public/frontend/img/favicon.png')}}">
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="{{ asset('/public/frontend/css/bootstrap.min.css') }}">
<!-- Normalize CSS -->
<link rel="stylesheet" href="{{ asset('/public/frontend/css/normalize.css') }}">
<!-- Main CSS -->
<link rel="stylesheet" href="{{ asset('/public/frontend/css/main.css') }}">
<!-- Animate CSS -->
<link rel="stylesheet" href="{{ asset('/public/frontend/css/animate.min.css') }}">
<!-- Font-awesome CSS-->
<link rel="stylesheet" href="{{ asset('/public/frontend/css/font-awesome.min.css') }}">
<!-- Flaticon CSS-->
<link rel="stylesheet" type="text/css" href="{{ asset('/public/frontend/css/font/flaticon.css') }}">
<!-- Owl Caousel CSS -->
<link rel="stylesheet" href="{{ asset('/public/frontend/css/owl.carousel.min.css') }}">
<link rel="stylesheet" href="{{ asset('/public/frontend/css/owl.theme.default.min.css') }}">
<!-- Main Menu CSS-->
<link rel="stylesheet" href="{{ asset('/public/frontend/css/meanmenu.min.css') }}">
<!-- Nivo Slider CSS-->
<link rel="stylesheet" href="{{ asset('/public/frontend/lib/custom-slider/css/nivo-slider.css') }}" 
type="text/css" />
<link rel="stylesheet" href="{{ asset('/public/frontend/lib/custom-slider/css/preview.css') }}" 
type="text/css" media="screen" />
<!-- Select2 CSS -->
<link rel="stylesheet" href="{{ asset('/public/frontend/css/select2.min.css') }}">
<!-- Custom CSS -->
<link rel="stylesheet" href="{{ asset('/public/frontend/style.css') }}">

<link rel="stylesheet" href="{{ asset('/public/frontend/app.css') }}">

