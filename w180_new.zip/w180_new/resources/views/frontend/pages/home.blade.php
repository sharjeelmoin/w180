@extends('frontend.layouts.master')
@section('title', $site_title)
@section('meta-description', $site_description)
@section('meta-keywords', $site_keywords)
@section('content')



<div class="container">
	<div class="row">
		<div class="col-md-6">
			asdsasd
		</div>
		<div class="col-md-6">
			asd
		</div>
	</div>
</div>











@include('frontend.pages.productModal')
@section('js')

<script src="{{asset('/public/project/addToCart.js')}}"></script>
<script src="{{asset('/public/project/product-modal.js')}}"></script>
@endsection
@endsection