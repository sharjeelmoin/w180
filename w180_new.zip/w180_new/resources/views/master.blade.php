<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</head>
<body>
	<div class="container">
		<div class="col-md-12">
			@yield('content')
		</div>
		<div class="col-md-3">
			@section('menu')
			<ul>
				<li> Home </li>
				<li> Services </li>
				<li> Contact Us </li>
			</ul>
		</div>
		<div class="col-md-9">
			@section('main')
			@show
		</div>
	</div>
</body>
</html>