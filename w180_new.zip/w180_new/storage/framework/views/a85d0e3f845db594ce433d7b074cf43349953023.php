<?php $__env->startSection('content'); ?>
<section class="banner">
	<div class="container">
		<div class="row">
			<div class="col-md-4">
				<h1>Make the most out of your job AT SALARY SURVEY</h1>
			</div>
			<div class="col-md-8"></div>
		</div>
	</div>
</section>
<section class="salaries">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h2>Salaries</h2>
			</div>
		</div>
	</div>
	<div class="red-bar">

	</div>
	<div class="container">
		<div class="row">
			<div class="col-md-4">
				<img class="icon-img" src="public/frontend/img/icon-img.png">
				<h5>Explore salaries across companies, jobs, and locations U.S</h5>
			</div>
			<div class="col-md-4">
				<img class="icon-img" src="public/frontend/img/icon-img.png">
				<h5>Explore salaries across companies, jobs, and locations U.S</h5>
			</div>
			<div class="col-md-4">
				<img class="icon-img" src="public/frontend/img/icon-img.png">
				<h5>Explore salaries across companies, jobs, and locations U.S</h5>
			</div>
			<a href="<?php echo e(url('/offer')); ?>" class="salaries-btn">Search salaries</a>
		</div>
	</div>
</section>

<section class="salaries">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h2>Salaries</h2>
			</div>
		</div>
	</div>
	<div class="red-bar">

	</div>
	<div class="container">
		<div class="row">
			<div class="col-md-4">
				<img class="icon-img" src="public/frontend/img/icon-img.png">
				<h5>Explore salaries across companies, jobs, and locations U.S</h5>
			</div>
			<div class="col-md-4">
				<img class="icon-img" src="public/frontend/img/icon-img.png">
				<h5>Explore salaries across companies, jobs, and locations U.S</h5>
			</div>
			<div class="col-md-4">
				<img class="icon-img" src="public/frontend/img/icon-img.png">
				<h5>Explore salaries across companies, jobs, and locations U.S</h5>
			</div>
			<a href="<?php echo e(url('/offer')); ?>" class="salaries-btn">Search salaries</a>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>