   

    <!-- Preloader End Here -->
    <!-- jquery-->
    <script src="<?php echo e(asset('public/frontend/js/vendor/jquery-2.2.4.min.js')); ?>" type="text/javascript"></script>
    <!-- Bootstrap js -->
    <script src="<?php echo e(asset('public/frontend/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
     <!-- Modernizr Js -->

    <!-- Countdown js -->
    <script src="<?php echo e(asset('public/frontend/js/jquery.countdown.min.js')); ?>" type="text/