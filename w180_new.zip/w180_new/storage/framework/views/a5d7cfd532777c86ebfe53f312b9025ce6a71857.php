<?php $__env->startSection('content'); ?>



<section class="salaries">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h2>First Tell Us About Your Job</h2>
			</div>
		</div>
	</div>
</section>
<section>
	<div class="container">
		<div class="row">
			<div class="col-md-4">
			    <select class="form-control" id="exampleFormControlSelect1">
			      	<option>1</option>
			      	<option>2</option>
			      	<option>3</option>
			      	<option>4</option>
			      	<option>5</option>
			    </select>
			</div>
			<div class="col-md-4">
			    <select class="form-control" id="exampleFormControlSelect1">
			      	<option>1</option>
			      	<option>2</option>
			      	<option>3</option>
			      	<option>4</option>
			      	<option>5</option>
			    </select>
			</div>
			<div class="col-md-4">
			    <select class="form-control" id="exampleFormControlSelect1">
			      	<option>1</option>
			      	<option>2</option>
			      	<option>3</option>
			      	<option>4</option>
			      	<option>5</option>
			    </select>
			</div>
		</div>

		<div class="row">
			<div class="col-md-4">
			    <select class="form-control" id="exampleFormControlSelect1">
			      	<option>1</option>
			      	<option>2</option>
			      	<option>3</option>
			      	<option>4</option>
			      	<option>5</option>
			    </select>
			</div>
			<div class="col-md-4">
			    <select class="form-control" id="exampleFormControlSelect1">
			      	<option>1</option>
			      	<option>2</option>
			      	<option>3</option>
			      	<option>4</option>
			      	<option>5</option>
			    </select>
			</div>
			<div class="col-md-4">
			    <select class="form-control" id="exampleFormControlSelect1">
			      	<option>1</option>
			      	<option>2</option>
			      	<option>3</option>
			      	<option>4</option>
			      	<option>5</option>
			    </select>
			</div>
		</div>

		<div class="row">
			<div class="col-md-4">
			    <select class="form-control" id="exampleFormControlSelect1">
			      	<option>1</option>
			      	<option>2</option>
			      	<option>3</option>
			      	<option>4</option>
			      	<option>5</option>
			    </select>
			</div>
			<div class="col-md-4">
			    <select class="form-control" id="exampleFormControlSelect1">
			      	<option>1</option>
			      	<option>2</option>
			      	<option>3</option>
			      	<option>4</option>
			      	<option>5</option>
			    </select>
			</div>
			<div class="col-md-4">
			    <select class="form-control" id="exampleFormControlSelect1">
			      	<option>1</option>
			      	<option>2</option>
			      	<option>3</option>
			      	<option>4</option>
			      	<option>5</option>
			    </select>
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>