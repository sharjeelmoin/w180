<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::view('/', 'welcome');*/
Route::get('/', 'MainController@index')->name('main');
Route::get('goto2', 'MainController@page2');

Auth::routes();
Route::get('/home', 'HomeController@index')->name('home');
Route::get('about', 'MainController@about')->name('about');
Route::get('offer', 'MainController@offer')->name('offer');
Route::get('/admin', 'AdminController@admin')->middleware('is_admin')->name('admin');

